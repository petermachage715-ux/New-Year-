const params = new URLSearchParams(window.location.search);
const name = params.get("name");

if (name) {
  document.getElementById("message").innerHTML =
  "🎉 Happy New Year " + name + " 🎉";
}

function share() {
  let n = document.getElementById("username").value;
  if (n == "") {
    alert("Andika jina kwanza");
    return;
  }

  let link = window.location.origin + window.location.pathname + "?name=" + n;
  let msg = "🎆 Happy New Year 🎆\nBonyeza link 👇\n" + link;

  window.open("https://wa.me/?text=" + encodeURIComponent(msg));
}